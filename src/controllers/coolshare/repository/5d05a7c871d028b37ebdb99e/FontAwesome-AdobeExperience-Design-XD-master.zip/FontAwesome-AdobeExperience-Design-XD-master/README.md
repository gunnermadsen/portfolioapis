# **FontAwesome Adobe Experience Design - Adobe XD**

This project provides an Adobe Experience Design XD file with Font-Awesome Free version SVG's included.

Fontawesome version: 5.4.2

## Updates:

- Fontawesome 5.4.2 free icon set
- Seperated Artboards: Solid, Regular, Brands
- Labeled layers
- Adobe XD 2019 - 13.0.12.14 file format

## About Fontawesome

Font Awesome is a full suite of 1,391 pictographic icons.
Maintained by [Dave Gandy](http://twitter.com/davegandy).  [@fontawesome](http://twitter.com/fontawesome).

http://fontawesome.io!

## License
- The Font Awesome font is licensed under the SIL OFL 1.1:
  - http://scripts.sil.org/OFL
- **Font-Awesome-Adobe-Experience-Design** is licensed under the MIT license

## How to use?
Download the fontawesome.xd file and use with Adobe Experience Design XD application.
